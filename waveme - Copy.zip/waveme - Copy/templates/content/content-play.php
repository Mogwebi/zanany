<?php
/**
 * Template part for displaying station
 */

?>
<div class="wp-block-loop block-loop-row">
	<div class="block-loop-items">
		<?php do_action('ffl_loop_template'); ?>
	</div>
</div>
