<?php
/**
 * Template part for displaying posts
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('block-loop-item'); ?>>
	<?php ffl_post_thumbnail(); ?>
</article>
